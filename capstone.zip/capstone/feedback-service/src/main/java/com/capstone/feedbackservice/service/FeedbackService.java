package com.capstone.feedbackservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.capstone.feedbackservice.model.Feedback;
import com.capstone.feedbackservice.repo.FeedbackRepo;

@Service
public class FeedbackService {

	@Autowired
	private FeedbackRepo feedbackRepo;
	
	public ResponseEntity<String> addReview(Feedback feedback)
	{
		feedbackRepo.save(feedback);
		return new ResponseEntity<>("Your feedback is submitted",HttpStatus.CREATED);
	}
	
	public ResponseEntity<Feedback> viewReview(int feedbackId)
	{
		Feedback feedback = feedbackRepo.findById(feedbackId).get();
		return new ResponseEntity<>(feedback,HttpStatus.OK);
	}
	
	public ResponseEntity<String> updateReview(int feedbackId,Feedback feedback)
	{
		Feedback existingFeedback = feedbackRepo.findById(feedbackId).get();
		
		if(feedback.getComments()==null)
		{
			existingFeedback.setComments(existingFeedback.getComments());
		}else {
			existingFeedback.setComments(feedback.getComments());
		}
		
		
		if(feedback.getRating()==0)
		{
			existingFeedback.setRating(existingFeedback.getRating());
		}else {
			existingFeedback.setRating(feedback.getRating());
		}
		
		feedbackRepo.save(existingFeedback);
		return new ResponseEntity<>("Your feedback is updated",HttpStatus.CREATED);
	}
}
