package com.capstone.customerservice.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;



@FeignClient("RESTUARANT-SERVICE")
public interface FeignInterface {

	@GetMapping("restuarant/menu/{restuarantName}")
	public ResponseEntity<List<com.capstone.customerservice.model.Menu>> getMenu(@PathVariable String restuarantName);
	
	
	@GetMapping("restuarant/allRestuarants")
	public ResponseEntity<List<com.capstone.customerservice.model.Restuarant>> getAllRestuarants();
}
