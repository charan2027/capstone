package com.capstone.customerservice.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


public class Menu {


	private int menuId;
	
	private String itemName;
	
	private int itemPrice;
	
	@ManyToOne
	@JoinColumn(name="restuarantId",nullable=false)
	private Restuarant restuarant;
	
	public Menu() {
		
	}

	public Menu(int menuId, String itemName, int itemPrice) {
		super();
		this.menuId = menuId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
	}

	public int getMenuId() {
		return menuId;
	}

	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	
	
}
