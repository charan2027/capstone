package com.capstone.customerservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.capstone.customerservice.feign.FeignInterface;
import com.capstone.customerservice.model.Customer;
import com.capstone.customerservice.model.Restuarant;
import com.capstone.customerservice.repo.CustomerRepo;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepo customerRepo;
	
	
	@Autowired
	private FeignInterface feign;
	
	public ResponseEntity<String> createCustomer(Customer customer)
	{
		customerRepo.save(customer);
		return new ResponseEntity<>("You account have registered successfully",HttpStatus.CREATED);
	}
	
	
	public ResponseEntity<String> deactivateCustomer(int id)
	{
		customerRepo.deleteById(id);
		return new ResponseEntity<>("Your account is deactivated...",HttpStatus.OK);
	}
	
	public ResponseEntity<String> updateCustomer(int id,Customer customer){
		Customer existingCustomerDetails = customerRepo.findById(id).get();
//		existingCustomerDetails.setCustomerEmail(customer.getCustomerEmail());
//		existingCustomerDetails.setCustomerName(customer.getCustomerName());
//		existingCustomerDetails.setCustomerLocation(customer.getCustomerLocation());
		if(customer.getCustomerEmail()==null)
		{
			existingCustomerDetails.setCustomerEmail(existingCustomerDetails.getCustomerEmail());
		}else {
			existingCustomerDetails.setCustomerEmail(customer.getCustomerEmail());
		}
		
		if(customer.getCustomerName()==null) {
			existingCustomerDetails.setCustomerName(existingCustomerDetails.getCustomerName());
		}else {
			existingCustomerDetails.setCustomerName(customer.getCustomerName());
		}
		
		if(customer.getCustomerLocation()==null)
		{
			existingCustomerDetails.setCustomerLocation(existingCustomerDetails.getCustomerLocation());
		}else {
			existingCustomerDetails.setCustomerLocation(customer.getCustomerLocation());
		}
		
		customerRepo.save(existingCustomerDetails);
		return new ResponseEntity<>("Customer updated successfully",HttpStatus.OK);
	}
	
	public List<Restuarant> getAllRestuarantsAvailable()
	{
		return feign.getAllRestuarants().getBody();
	}
}
