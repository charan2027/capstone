package com.capstone.customerservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.customerservice.model.Customer;
import com.capstone.customerservice.model.Restuarant;
import com.capstone.customerservice.service.CustomerService;

@RestController
@RequestMapping("customer")
public class CustomerController {

	
	@Autowired
	private CustomerService customerservice;
	
	@PostMapping("createCustomer")
	public ResponseEntity<String> addCustomer(@RequestBody Customer customer)
	{
		return customerservice.createCustomer(customer);
	}
	
	@DeleteMapping("deactivateCustomer/{id}")
	public ResponseEntity<String> deactivateCustomer(@PathVariable int id)
	{
		return customerservice.deactivateCustomer(id);
	}
	
	@PatchMapping("updateCustomer/{id}")
	public ResponseEntity<String> updateCustomer(@PathVariable int id,@RequestBody Customer customer)
	{
		return customerservice.updateCustomer(id, customer);
	}
	
	@GetMapping("availableRestuarants")
	public List<Restuarant> findAllRestuarnts()
	{
		return customerservice.getAllRestuarantsAvailable();
	}
}
