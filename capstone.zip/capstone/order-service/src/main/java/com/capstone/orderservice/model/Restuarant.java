package com.capstone.orderservice.model;

import java.util.List;

import jakarta.persistence.OneToMany;

public class Restuarant {

	public int restuarantId;
	
	private String restuarantName;
	
	private String restuarantLocation;
	
	private String cuisine;
	
	private int budget;
	
	private float rating;
	
	@OneToMany(mappedBy="restuarant")
	//@JoinColumn(name="menuId")
	//@OrderColumn(name="type")
	private List<Menu> menu;
	
	public Restuarant() {
		
	}

	

	public Restuarant(int restuarantId, String restuarantName, String restuarantLocation, String cuisine, int budget,
			float rating, List<Menu> menu) {
		super();
		this.restuarantId = restuarantId;
		this.restuarantName = restuarantName;
		this.restuarantLocation = restuarantLocation;
		this.cuisine = cuisine;
		this.budget = budget;
		this.rating = rating;
		this.menu = menu;
	}



	public int getRestuarantId() {
		return restuarantId;
	}

	public void setRestuarantId(int restuarantId) {
		this.restuarantId = restuarantId;
	}

	public String getRestuarantName() {
		return restuarantName;
	}

	public void setRestuarantName(String restuarantName) {
		this.restuarantName = restuarantName;
	}

	public String getRestuarantLocation() {
		return restuarantLocation;
	}

	public void setRestuarantLocation(String restuarantLocation) {
		this.restuarantLocation = restuarantLocation;
	}

	public String getCuisine() {
		return cuisine;
	}

	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}

	public int getBudget() {
		return budget;
	}

	public void setBudget(int budget) {
		this.budget = budget;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}



	public List<Menu> getMenu() {
		return menu;
	}



	public void setMenu(List<Menu> menu) {
		this.menu = menu;
	}

	
	
	
}
