package com.capstone.orderservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.capstone.orderservice.model.Order;
import com.capstone.orderservice.repo.OrderRepo;

@Service
public class OrderService {

	@Autowired
	private OrderRepo orderRepo;
	
	public ResponseEntity<Order> placeOrder(Order order)
	{
		return new ResponseEntity<>(orderRepo.save(order),HttpStatus.CREATED);
	}
	
	public ResponseEntity<String> cancelOrder(int orderId){
		orderRepo.deleteById(orderId);
		return new ResponseEntity<>("Order cancelled successfully...",HttpStatus.OK);
	}
	
	public ResponseEntity<Order> findOrderByOrderId(int orderId)
	{
		Order order = orderRepo.findById(orderId).get();
		return new ResponseEntity<>(order,HttpStatus.OK);
	}
	
	public ResponseEntity<Order> updateOrder(int orderId , Order order)
	{
		Order existingOrder = orderRepo.findById(orderId).get();
		
//		if(order.getItemsOrdered()==null)
//		{
//			existingOrder.setItemsOrdered(existingOrder.getItemsOrdered());
//		}
//		else {
//			existingOrder.setItemsOrdered(order.getItemsOrdered());
//		}
		
		if(order.getRestuarantId()==0) {
			existingOrder.setRestuarantId(existingOrder.getRestuarantId());
		}else {
			existingOrder.setRestuarantId(order.getRestuarantId());
		}
		
		existingOrder.setCustomerId(existingOrder.getCustomerId());
		existingOrder.setOrderStatus(existingOrder.getOrderStatus());
		existingOrder.setTotalPrice(existingOrder.getTotalPrice());
		
		orderRepo.save(existingOrder);
		return new ResponseEntity<>(existingOrder,HttpStatus.OK);
	}
} 
