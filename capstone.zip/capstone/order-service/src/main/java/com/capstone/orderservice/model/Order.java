package com.capstone.orderservice.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="orderr")
public class Order {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	
	private int customerId;
	
	private int restuarantId;
	
	private String orderStatus;
	
	//@OneToMany(mappedBy="order")
	//private List<Menu> itemsOrdered;
	
	private int totalPrice;
	
	
	
	public Order() {
		
	}

//	public Order(int orderId, int customerId, int restuarantId, String orderStatus, List<Menu> itemsOrdered,
//			int totalPrice) {
//		super();
//		this.orderId = orderId;
//		this.customerId = customerId;
//		this.restuarantId = restuarantId;
//		this.orderStatus = orderStatus;
//		this.itemsOrdered = itemsOrdered;
//		this.totalPrice = totalPrice;
//	}
	
	

	public int getOrderId() {
		return orderId;
	}

	public Order(int orderId, int customerId, int restuarantId, String orderStatus, int totalPrice) {
	super();
	this.orderId = orderId;
	this.customerId = customerId;
	this.restuarantId = restuarantId;
	this.orderStatus = orderStatus;
	this.totalPrice = totalPrice;
}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getRestuarantId() {
		return restuarantId;
	}

	public void setRestuarantId(int restuarantId) {
		this.restuarantId = restuarantId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

//	public List<Menu> getItemsOrdered() {
//		return itemsOrdered;
//	}
//
//	public void setItemsOrdered(List<Menu> itemsOrdered) {
//		this.itemsOrdered = itemsOrdered;
//	}

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	
}
