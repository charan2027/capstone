package com.capstone.restuarantservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.capstone.restuarantservice.model.Menu;
import com.capstone.restuarantservice.repo.MenuRepo;

@Service
public class MenuItemService {

	

	
	
	@Autowired
	private MenuRepo menuRepo;
	
	
	
	public Menu addMenu(Menu menu)
	{
		return menuRepo.save(menu);
	}
}
