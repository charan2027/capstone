package com.capstone.restuarantservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.capstone.restuarantservice.model.Menu;
import com.capstone.restuarantservice.model.Restuarant;
import com.capstone.restuarantservice.repo.RestuarantRepo;

@Service
public class RestuarantService {

	@Autowired
	private RestuarantRepo restuarantRepo;
	
	public ResponseEntity<String> createRestuarant(Restuarant restuarant)
	{
		restuarantRepo.save(restuarant);
		return new ResponseEntity<>("Restuarant created ....",HttpStatus.OK);
	}
	
	public ResponseEntity<List<Restuarant>> getAllRestuarants()
	{
		List<Restuarant> allRestuarants = restuarantRepo.findAll();
		return new ResponseEntity<>(allRestuarants,HttpStatus.OK);
	}
	
	public ResponseEntity<List<Restuarant>> findRestuarantByLocation(String location)
	{
		List<Restuarant> restuarantsByLocation = restuarantRepo.findRestuarantByrestuarantLocation(location);
		return new ResponseEntity<>(restuarantsByLocation,HttpStatus.OK);
	}
	
//	public ResponseEntity<Restuarant> findRestuarantByRestuarantName(String restuarantName)
//	{
//		Restuarant restuarantsByName = restuarantRepo.findRestuarantsByrestuarantName(restuarantName);
//		return new ResponseEntity<>(restuarantsByName,HttpStatus.OK);
//	}
	
	public ResponseEntity<List<Restuarant>> findRestuarantsByCuisine(String cuisine){
		List<Restuarant> restuarantsByCuisine = restuarantRepo.findRestuarantBycuisine(cuisine);
		return new ResponseEntity<>(restuarantsByCuisine,HttpStatus.OK);
	}
	
	public ResponseEntity<List<Restuarant>> findRestuarantsByBudget(int budget)
	{
		List<Restuarant> restuarantsByBudget = restuarantRepo.findRestuarantBybudget(budget);
		return new ResponseEntity<>(restuarantsByBudget,HttpStatus.OK);
	}
	
	public ResponseEntity<List<Restuarant>> findRestuarantsByRating(float rating){
		List<Restuarant> restuarantsByRating = restuarantRepo.findRestuarantByrating(rating);
		return new ResponseEntity<>(restuarantsByRating,HttpStatus.OK);
	}
	
	public ResponseEntity<Restuarant> getRestuarantByRestuarantName(String restuarantName)
	{
		Restuarant restuarantByName = restuarantRepo.findRestuarantByrestuarantName(restuarantName);
		return new ResponseEntity<>(restuarantByName,HttpStatus.OK);
	}
	
	public ResponseEntity<List<Menu>> getMenuOfRestuarant(String restuarantName)
	{
		List<Menu> menu =  restuarantRepo.findRestuarantByrestuarantName(restuarantName).getMenu();
		return new ResponseEntity<>(menu,HttpStatus.OK);
	}
}
