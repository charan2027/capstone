package com.capstone.restuarantservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.restuarantservice.model.Menu;
import com.capstone.restuarantservice.model.Restuarant;
import com.capstone.restuarantservice.service.RestuarantService;

@RestController
@RequestMapping("restuarant")
public class RestuarantController {

	@Autowired
	private RestuarantService restuarantService;
	
	@PostMapping("createRestuarant")
	public ResponseEntity<String> createRestuarant(@RequestBody Restuarant restuarant)
	{
		return restuarantService.createRestuarant(restuarant);
	}
	
	@GetMapping("allRestuarants")
	public ResponseEntity<List<Restuarant>> getAllRestuarants()
	{
		return restuarantService.getAllRestuarants();
	}
	
	@GetMapping("location/{restuarantLocation}")
	public ResponseEntity<List<Restuarant>> getRestuarantsByLocation(@PathVariable String restuarantLocation)
	{
		return restuarantService.findRestuarantByLocation(restuarantLocation);
	}
	
	@GetMapping("restuarantName/{restuarantName}")
	public ResponseEntity<Restuarant> getRestuarantsByRestuarantName(@PathVariable String restuarantName){
		return restuarantService.getRestuarantByRestuarantName(restuarantName);
	}
	
	@GetMapping("cuisine/{cuisine}")
	public ResponseEntity<List<Restuarant>> getRestuarantsByCuisine(@PathVariable String cuisine)
	{
		return restuarantService.findRestuarantsByCuisine(cuisine);
	}
	
	@GetMapping("budget/{budget}")
	public ResponseEntity<List<Restuarant>> getRestuarantsByBudget(@PathVariable int budget){
		return restuarantService.findRestuarantsByBudget(budget);
	}
	
	@GetMapping("rating/{rating}")
	public ResponseEntity<List<Restuarant>> getRestuarantByRating(@PathVariable float rating)
	{
		return restuarantService.findRestuarantsByRating(rating);
	}
	
	@GetMapping("menu/{restuarantName}")
	public ResponseEntity<List<Menu>> getMenu(@PathVariable String restuarantName)
	{
		return restuarantService.getMenuOfRestuarant(restuarantName);
	}

}
