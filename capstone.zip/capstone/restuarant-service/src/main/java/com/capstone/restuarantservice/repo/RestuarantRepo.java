package com.capstone.restuarantservice.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capstone.restuarantservice.model.Menu;
import com.capstone.restuarantservice.model.Restuarant;

@Repository
public interface RestuarantRepo extends JpaRepository<Restuarant, Integer> {

	List<Restuarant> findRestuarantByrestuarantLocation(String restuarantLocation);

	//Restuarant findRestuarantsByrestuarantName(String restuarantName);

	List<Restuarant> findRestuarantBycuisine(String cuisine);
 
	List<Restuarant> findRestuarantBybudget(int budget);

	List<Restuarant> findRestuarantByrating(float rating);

	Restuarant findRestuarantByrestuarantName(String restuarantName);

	//Menu findMenu(String restuarantName);

	
  
}
 