package com.capstone.restuarantservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstone.restuarantservice.model.Menu;

public interface MenuRepo extends JpaRepository<Menu, Integer> {

}
