package com.capstone.restuarantservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestuarantServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
